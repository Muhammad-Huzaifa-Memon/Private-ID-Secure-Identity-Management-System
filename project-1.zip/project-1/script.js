
// ==========================================
// PRIVATE ID - ADVANCED PRIVACY ANALYZER
// ==========================================

const inputText = document.getElementById("inputText");
const analyzeBtn = document.getElementById("analyzeBtn");
const clearBtn = document.getElementById("clearBtn");

const emptyState = document.getElementById("emptyState");
const results = document.getElementById("results");
const highlightedText = document.getElementById("highlightedText");

let totalScans = 0;
let totalThreats = 0;
let lastReport = null;

// ==========================================
// DETECTION PATTERNS
// ==========================================

const patterns = {
    email: {
        regex: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi,
        weight: 15
    },

    phone: {
        regex: /(?<!\d)(?:\+?92[\s-]?3\d{2}|03\d{2})[\s-]?\d{7}(?!\d)/g,
        weight: 20
    },

    cnic: {
        regex: /(?<!\d)\d{5}-\d{7}-\d(?!\d)/g,
        weight: 30
    },

    password: {
        regex: /\b(?:password|passwd|passcode|pwd|secret|api[_ -]?key|access[_ -]?token)\b\s*[:=]\s*[^\s,;]+/gi,
        weight: 35
    }
};

// ==========================================
// CHARACTER COUNTER
// ==========================================

inputText.addEventListener("input", () => {
    document.getElementById("charCount").textContent =
        `${inputText.value.length} characters`;
});

// ==========================================
// ANALYZE TEXT
// ==========================================

analyzeBtn.addEventListener("click", analyzeText);

function analyzeText() {

    const text = inputText.value;

    if (!text.trim()) {
        showToast("Please enter some text first!");
        return;
    }

    const findings = [];

    Object.entries(patterns).forEach(([type, config]) => {

        const regex = new RegExp(
            config.regex.source,
            config.regex.flags
        );

        let match;

        while ((match = regex.exec(text)) !== null) {

            findings.push({
                type,
                value: match[0],
                start: match.index,
                end: match.index + match[0].length,
                weight: config.weight
            });

            if (match[0].length === 0) {
                regex.lastIndex++;
            }
        }
    });

    // ======================================
    // IMPROVED RISK SCORE
    // ======================================

    const weights = {
        email: 15,
        phone: 20,
        cnic: 30,
        password: 35
    };

    const counts = {
        email: 0,
        phone: 0,
        cnic: 0,
        password: 0
    };

    findings.forEach(item => {
        counts[item.type]++;
    });

    // Category-based scoring avoids excessive
    // penalties for repeated occurrences.
    const rawRisk = Object.entries(weights).reduce(
        (total, [type, weight]) => {
            return total + Math.min(counts[type], 3) * weight;
        },
        0
    );

    const riskScore = Math.min(100, rawRisk);
    const privacyScore = 100 - riskScore;

    // Statistics
    totalScans++;
    totalThreats += findings.length;

    document.getElementById("totalScans").textContent = totalScans;
    document.getElementById("totalThreats").textContent = totalThreats;

    document.getElementById("privacyScore").innerHTML =
        `${privacyScore}<span class="percentage">%</span>`;

    document.getElementById("protectionStatus").textContent =
        findings.length ? "At Risk" : "Protected";

    // Show results
    emptyState.classList.add("hidden");
    results.classList.remove("hidden");

    displayCounts(counts);
    displayRisk(riskScore);
    displayRecommendations(findings);
    highlightFindings(text, findings);

    lastReport = {
        date: new Date().toLocaleString(),
        riskScore,
        privacyScore,
        findings,
        counts,
        recommendations: getRecommendations(findings)
    };

    showToast(`${findings.length} sensitive items detected!`);
}

// ==========================================
// DISPLAY COUNTS
// ==========================================

function displayCounts(counts) {

    document.getElementById("emailCount").textContent = counts.email;
    document.getElementById("phoneCount").textContent = counts.phone;
    document.getElementById("cnicCount").textContent = counts.cnic;
    document.getElementById("passwordCount").textContent = counts.password;
}

// ==========================================
// RISK DISPLAY
// ==========================================

function displayRisk(score) {

    const circle = document.getElementById("scoreCircle");
    const level = document.getElementById("riskLevel");

    document.getElementById("riskScore").textContent = score;
    document.getElementById("circleScore").textContent = score;

    let color;
    let label;

    if (score <= 30) {
        color = "#00dfa2";
        label = "LOW RISK";
    } else if (score <= 60) {
        color = "#ffae57";
        label = "MEDIUM RISK";
    } else {
        color = "#ff5378";
        label = "HIGH RISK";
    }

    circle.style.background =
        `conic-gradient(${color} ${score * 3.6}deg, #24384b 0deg)`;

    document.getElementById("circleScore").style.color = color;

    level.textContent = label;
    level.style.color = color;
    level.style.background = `${color}18`;
}

// ==========================================
// RECOMMENDATIONS
// ==========================================

function getRecommendations(findings) {

    const types = new Set(findings.map(item => item.type));
    const recommendations = [];

    if (types.has("email")) {
        recommendations.push(
            "Avoid sharing personal email addresses publicly."
        );
    }

    if (types.has("phone")) {
        recommendations.push(
            "Keep your phone number private and avoid suspicious calls."
        );
    }

    if (types.has("cnic")) {
        recommendations.push(
            "Remove exposed CNIC numbers from public documents and posts."
        );
    }

    if (types.has("password")) {
        recommendations.push(
            "Change exposed passwords and revoke exposed API keys or tokens."
        );
    }

    if (findings.length === 0) {
        recommendations.push(
            "No supported sensitive patterns were detected. This does not guarantee complete privacy."
        );
    }

    recommendations.push(
        "Enable two-factor authentication on important accounts."
    );

    return recommendations;
}

function displayRecommendations(findings) {

    const list = document.getElementById("recommendationsList");
    list.replaceChildren();

    getRecommendations(findings).forEach(item => {
        const li = document.createElement("li");
        li.textContent = item;
        list.appendChild(li);
    });
}

// ==========================================
// MASK SENSITIVE INFORMATION
// ==========================================

function maskSensitive(value, type) {

    if (type === "email") {
        const parts = value.split("@");
        return parts[0].slice(0, 1) + "****@" + parts[1];
    }

    if (type === "phone") {
        return value.slice(0, 4) + "****" + value.slice(-2);
    }

    if (type === "cnic") {
        return value.slice(0, 5) + "-*******-" + value.slice(-1);
    }

    if (type === "password") {
        return "[REDACTED]";
    }

    return "****";
}

// ==========================================
// SAFE TEXT HIGHLIGHTING
// ==========================================

function highlightFindings(text, findings) {

    const sorted = [...findings].sort(
        (a, b) => a.start - b.start || b.end - a.end
    );

    const fragment = document.createDocumentFragment();
    let cursor = 0;

    sorted.forEach(item => {

        if (item.start < cursor) return;

        fragment.appendChild(
            document.createTextNode(text.slice(cursor, item.start))
        );

        const mark = document.createElement("mark");
        mark.className = item.type;
        mark.textContent = text.slice(item.start, item.end);
        mark.title = item.type.toUpperCase();

        fragment.appendChild(mark);

        cursor = item.end;
    });

    fragment.appendChild(
        document.createTextNode(text.slice(cursor))
    );

    highlightedText.replaceChildren(fragment);
}

// ==========================================
// CLEAR
// ==========================================

clearBtn.addEventListener("click", () => {

    inputText.value = "";
    document.getElementById("charCount").textContent = "0 characters";

    emptyState.classList.remove("hidden");
    results.classList.add("hidden");

    const placeholder = document.createElement("span");
    placeholder.className = "placeholder-text";
    placeholder.textContent =
        "Your highlighted analysis will appear here.";

    highlightedText.replaceChildren(placeholder);

    lastReport = null;

    showToast("Analyzer cleared successfully.");
});

// ==========================================
// GENERATE PROFESSIONAL REPORT
// ==========================================

document.getElementById("downloadBtn").addEventListener("click", () => {

    if (!lastReport) {
        showToast("Please analyze text first!");
        return;
    }

    const report = lastReport;

    const categoryNames = {
        email: "Email Address",
        phone: "Phone Number",
        cnic: "CNIC Number",
        password: "Password / Secret"
    };

    const riskLabel =
        report.riskScore <= 30
            ? "LOW RISK"
            : report.riskScore <= 60
                ? "MEDIUM RISK"
                : "HIGH RISK";

    // Build a safe HTML report using DOM escaping.
    const escapeHTML = value =>
        String(value).replace(/[&<>"']/g, char => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        })[char]);

    const findingRows = report.findings.map(item => `
        <tr>
            <td>${escapeHTML(categoryNames[item.type])}</td>
            <td>${escapeHTML(maskSensitive(item.value, item.type))}</td>
            <td>Detected</td>
        </tr>
    `).join("");

    const recommendations = report.recommendations.map(item => `
        <li>${escapeHTML(item)}</li>
    `).join("");

    const html = `
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Private ID Security Report</title>

<style>
    * { box-sizing: border-box; }

    body {
        font-family: Arial, sans-serif;
        color: #17263b;
        padding: 35px;
        background: #f3f7fb;
    }

    .report {
        max-width: 850px;
        margin: auto;
        background: white;
        padding: 40px;
        border-radius: 12px;
    }

    .header {
        background: #0b1728;
        color: white;
        padding: 27px;
        border-radius: 10px;
    }

    .header h1 {
        color: #00d9ee;
        margin: 0 0 8px;
    }

    .header p {
        color: #b5c7db;
        font-size: 13px;
    }

    .score {
        margin: 25px 0;
        padding: 22px;
        background: #fff0f1;
        border-left: 5px solid #ff5378;
        border-radius: 8px;
    }

    .score h2 {
        color: #e63960;
        font-size: 35px;
        margin: 5px 0;
    }

    .summary {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 12px;
        margin: 20px 0;
    }

    .item {
        background: #f0f6fc;
        padding: 16px;
        border-radius: 8px;
    }

    .item strong {
        font-size: 24px;
        color: #087dba;
        display: block;
    }

    h3 {
        margin-top: 28px;
        color: #102c4b;
        border-bottom: 2px solid #00d9ee;
        padding-bottom: 9px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
        font-size: 12px;
    }

    th {
        background: #10243d;
        color: white;
        text-align: left;
    }

    th, td {
        padding: 12px;
        border: 1px solid #dbe5ef;
        word-break: break-word;
    }

    ul {
        padding-left: 22px;
        line-height: 2;
        font-size: 13px;
    }

    .footer {
        border-top: 1px solid #dbe5ef;
        margin-top: 35px;
        padding-top: 18px;
        text-align: center;
        color: #718096;
        font-size: 11px;
    }

    @media print {
        body {
            padding: 0;
            background: white;
        }

        .report {
            padding: 15px;
            box-shadow: none;
        }

        .header, th {
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
        }
    }
</style>
</head>

<body>

<div class="report">

    <div class="header">
        <h1>🛡 PRIVATE ID</h1>
        <h2>Security Analysis Report</h2>
        <p>Digital Privacy Protection System</p>
        <p>Generated: ${escapeHTML(report.date)}</p>
    </div>

    <div class="score">
        <p>PRIVACY RISK SCORE</p>
        <h2>${report.riskScore}/100</h2>
        <strong>${riskLabel}</strong>
        <p>Privacy Score: ${report.privacyScore}/100</p>
    </div>

    <h3>Detection Summary</h3>

    <div class="summary">
        <div class="item">
            <strong>${report.counts.email}</strong>
            Emails
        </div>

        <div class="item">
            <strong>${report.counts.phone}</strong>
            Phone Numbers
        </div>

        <div class="item">
            <strong>${report.counts.cnic}</strong>
            CNIC Numbers
        </div>

        <div class="item">
            <strong>${report.counts.password}</strong>
            Passwords / Secrets
        </div>
    </div>

    <h3>Detailed Findings (Masked)</h3>

    <table>
        <thead>
            <tr>
                <th>Category</th>
                <th>Masked Information</th>
                <th>Status</th>
            </tr>
        </thead>

        <tbody>
            ${findingRows || `
                <tr>
                    <td colspan="3">No sensitive patterns detected.</td>
                </tr>
            `}
        </tbody>
    </table>

    <h3>Security Recommendations</h3>

    <ul>
        ${recommendations}
    </ul>

    <div class="footer">
        <strong>PRIVATE ID - Your Digital Privacy, Protected.</strong>
        <p>Automated pattern-based analysis. Not a certified security assessment.</p>
        <p>Original scanned text and unmasked values are not included in this report.</p>
    </div>

</div>

<script>
    window.onload = () => window.print();
<\/script>

</body>
</html>`;

    const blob = new Blob([html], {
        type: "text/html;charset=utf-8"
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = "Private-ID-Security-Report.html";

    document.body.appendChild(link);
    link.click();
    link.remove();

    setTimeout(() => URL.revokeObjectURL(url), 10000);

    showToast("Professional report downloaded! Open it and select Save as PDF.");
});

// ==========================================
// CHATBOT
// ==========================================

const chatForm = document.getElementById("chatForm");
const chatInput = document.getElementById("chatInput");
const chatMessages = document.getElementById("chatMessages");

function addMessage(message, sender) {

    const div = document.createElement("div");

    div.className =
        sender === "user"
            ? "message user-message"
            : "message bot-message";

    div.textContent = message;

    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function getBotResponse(question) {

    const q = question.toLowerCase();

    if (q.includes("cnic")) {
        return "Your CNIC is highly sensitive. Never publish your complete CNIC publicly. Share it only with verified organizations when necessary.";
    }

    if (q.includes("password")) {
        return "Use unique passwords of at least 12-16 characters, a password manager and two-factor authentication. Change any exposed password immediately.";
    }

    if (q.includes("email")) {
        return "Avoid publishing your personal email. Use separate email addresses for public registrations and important accounts.";
    }

    if (q.includes("phone") || q.includes("mobile")) {
        return "Keep your phone number private. Never share OTPs or verification codes with unknown callers.";
    }

    if (q.includes("phishing")) {
        return "Phishing is a cyberattack where criminals impersonate trusted services to steal your information. Check links carefully before clicking.";
    }

    if (q.includes("privacy") || q.includes("protect")) {
        return "Protect your identity using strong passwords, 2FA, secure websites and by limiting the personal information you share online.";
    }

    if (q.includes("hello") || q.includes("hi")) {
        return "Hello! Welcome to Private ID. Ask me anything about your digital privacy.";
    }

    if (q.includes("thank")) {
        return "You're welcome! Stay safe and protect your digital identity.";
    }

    return "I can help with CNIC safety, phone privacy, email protection, passwords, phishing and cybersecurity.";
}

chatForm.addEventListener("submit", event => {

    event.preventDefault();

    const question = chatInput.value.trim();

    if (!question) return;

    addMessage(question, "user");
    chatInput.value = "";

    setTimeout(() => {
        addMessage(getBotResponse(question), "bot");
    }, 300);
});

document.querySelectorAll(".quick-btn").forEach(button => {

    button.addEventListener("click", () => {
        chatInput.value = button.textContent;
        chatForm.requestSubmit();
    });
});

// ==========================================
// TOAST
// ==========================================

let toastTimer;

function showToast(message) {

    const toast = document.getElementById("toast");

    toast.textContent = message;
    toast.classList.add("show");

    clearTimeout(toastTimer);

    toastTimer = setTimeout(() => {
        toast.classList.remove("show");
    }, 2500);
}

// ==========================================
// SIDEBAR
// ==========================================

document.querySelectorAll(".nav-link").forEach(link => {

    link.addEventListener("click", () => {

        document.querySelectorAll(".nav-link").forEach(item => {
            item.classList.remove("active");
        });

        link.classList.add("active");
    });
});

console.log("Private ID Advanced Privacy Engine Initialized.");
